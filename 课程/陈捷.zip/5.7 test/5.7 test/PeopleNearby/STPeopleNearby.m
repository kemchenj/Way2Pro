//
//  STPeopleNearbyViewController.m
//  5.7 test
//
//  Created by kemchenj on 5/7/16.
//  Copyright © 2016 kemchenj. All rights reserved.
//

#import "STPeopleNearby.h"



@interface STPeopleNearby ()

@end



@implementation STPeopleNearby

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.navigationController.title = @"People Nearby";

    self.navigationItem.leftItemsSupplementBackButton = YES;
}

@end
