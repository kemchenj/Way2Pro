//
//  STPeopleNearby.h
//  5.7 test
//
//  Created by kemchenj on 5/8/16.
//  Copyright © 2016 kemchenj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STPeopleNearby : UIViewController

@end