//
//  NavigationBarCenter.h
//  5.7 test
//
//  Created by kemchenj on 5/7/16.
//  Copyright © 2016 kemchenj. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface STNavigationBarTitleView : UIView

@property (nonatomic, assign) float percent;

@end
