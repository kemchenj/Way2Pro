//
// Created by kemchenj on 5/8/16.
// Copyright (c) 2016 kemchenj. All rights reserved.
//


#import <UIKit/UIKit.h>



@class STViewController;



@interface STNavigationController : UINavigationController

+ (instancetype)navigationControllerWithView;

@end