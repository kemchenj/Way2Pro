//
//  STHeroViewTableViewCell.h
//  5.4 Test
//
//  Created by kemchenj on 5/4/16.
//  Copyright © 2016 kemchenj. All rights reserved.
//

#import <UIKit/UIKit.h>
@class STHero;

@interface STHeroCell : UITableViewCell

@property (nonatomic, strong) STHero *hero;

@end
