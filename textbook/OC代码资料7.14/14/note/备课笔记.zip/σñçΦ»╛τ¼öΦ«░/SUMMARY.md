# Summary

* [OC中的私有方法 ](README.md)
* [@property基本概念 ](property/README.md)
* [@synthesize基本概念](synthesize/README.md)
* [@property增强](5.md)
* [@property修饰符](6.md)
* [id类型](id/README.md)
* [new方法实现原理](new/README.md)
* [构造方法](9.md)
* [自定义构造方法](10.md)
* [继承中的自定义构造方法](12.md)
* [自定义类工厂方法](13.md)
* [类的本质](1.md)
* [类的启动过程](14.md)
* [SEL类型](sel/README.md)

